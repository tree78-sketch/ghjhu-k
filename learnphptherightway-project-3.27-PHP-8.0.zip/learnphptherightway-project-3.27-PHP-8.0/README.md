#### The source code for the PHP course "Learn PHP The Right Way" lesson 3.27.

---
#### Course Playlist
https://www.youtube.com/watch?v=sVbEyFZKgqk&list=PLr3d3QYzkw2xabQRUpcZ_IBk9W50M9pe-

#### Course Video Outline
https://github.com/ggelashvili/learnphptherightway-outline
