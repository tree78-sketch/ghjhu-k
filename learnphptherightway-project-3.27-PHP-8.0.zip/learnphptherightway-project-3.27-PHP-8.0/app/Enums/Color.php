<?php

declare(strict_types = 1);

namespace App\Enums;

class Color
{
    const Green  = 'green';
    const Red    = 'red';
    const Gray   = 'gray';
    const Orange = 'orange';
}
